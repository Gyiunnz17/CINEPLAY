# CinePlay: regras adicionais serão adicionadas quando integraremos rede/banco.
