package com.cineplay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF8B5CF6)
private val PurpleDark = Color(0xFF5B21B6)
private val Background = Color(0xFF09090B)
private val SurfaceDark = Color(0xFF15131A)

data class Movie(
    val id: Int,
    val title: String,
    val year: Int,
    val genre: String,
    val rating: Double,
    val description: String,
    val isSeries: Boolean = false
)

private val demoMovies = listOf(
    Movie(1, "A Última Fronteira", 2026, "Ficção científica", 8.7, "Uma equipe parte em uma missão que pode mudar o futuro da humanidade."),
    Movie(2, "Cidade Sombria", 2025, "Suspense", 8.2, "Segredos começam a surgir quando uma cidade aparentemente tranquila muda completamente."),
    Movie(3, "Horizonte", 2026, "Drama", 8.5, "Uma história sobre escolhas, amizade e novos caminhos.", true),
    Movie(4, "Código Zero", 2025, "Ação", 7.9, "Um grupo precisa descobrir a origem de um misterioso código antes que seja tarde."),
    Movie(5, "Depois da Chuva", 2024, "Drama", 8.1, "Uma família tenta recomeçar após uma grande mudança."),
    Movie(6, "Arquivo 13", 2026, "Mistério", 8.8, "Um arquivo esquecido revela uma história que ninguém esperava encontrar.", true)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinePlayApp() }
    }
}

@Composable
fun CinePlayApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var selectedMovie by remember { mutableStateOf<Movie?>(null) }
    var favorites by remember { mutableStateOf(setOf<Int>()) }

    MaterialTheme(
        colorScheme = MaterialTheme.colorScheme.copy(
            primary = Purple,
            secondary = PurpleDark,
            background = Background,
            surface = SurfaceDark
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Background) {
            if (selectedMovie != null) {
                DetailsScreen(
                    movie = selectedMovie!!,
                    isFavorite = selectedMovie!!.id in favorites,
                    onBack = { selectedMovie = null },
                    onFavorite = {
                        favorites = if (selectedMovie!!.id in favorites)
                            favorites - selectedMovie!!.id
                        else favorites + selectedMovie!!.id
                    }
                )
            } else {
                Scaffold(
                    containerColor = Background,
                    bottomBar = {
                        NavigationBar(containerColor = SurfaceDark) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.Home, null) },
                                label = { Text("Início") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.Search, null) },
                                label = { Text("Pesquisar") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.Favorite, null) },
                                label = { Text("Favoritos") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                icon = { Icon(Icons.Default.Person, null) },
                                label = { Text("Perfil") }
                            )
                        }
                    }
                ) { padding ->
                    when (selectedTab) {
                        0 -> HomeScreen(
                            padding = padding,
                            movies = demoMovies,
                            favorites = favorites,
                            onMovie = { selectedMovie = it },
                            onFavorite = { movie ->
                                favorites = if (movie.id in favorites) favorites - movie.id
                                else favorites + movie.id
                            }
                        )
                        1 -> SearchScreen(
                            padding = padding,
                            movies = demoMovies,
                            favorites = favorites,
                            onMovie = { selectedMovie = it },
                            onFavorite = { movie ->
                                favorites = if (movie.id in favorites) favorites - movie.id
                                else favorites + movie.id
                            }
                        )
                        2 -> FavoritesScreen(
                            padding = padding,
                            movies = demoMovies.filter { it.id in favorites },
                            onMovie = { selectedMovie = it },
                            onFavorite = { movie -> favorites = favorites - movie.id }
                        )
                        else -> ProfileScreen(padding)
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    padding: PaddingValues,
    movies: List<Movie>,
    favorites: Set<Int>,
    onMovie: (Movie) -> Unit,
    onFavorite: (Movie) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp)
                    .background(
                        Brush.verticalGradient(listOf(PurpleDark, Background))
                    )
                    .padding(20.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Column {
                    Text("CINEPLAY", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Filmes e séries em um só lugar", color = Color.White.copy(alpha = .8f))
                    Spacer(Modifier.height(12.dp))
                    Text("DESTAQUE", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(movies.first().title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { SectionTitle("Em destaque") }
        item {
            MovieRow(movies.take(4), favorites, onMovie, onFavorite)
        }
        item { SectionTitle("Séries") }
        item {
            MovieRow(movies.filter { it.isSeries }, favorites, onMovie, onFavorite)
        }
        item { SectionTitle("Categorias") }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf("Ação", "Drama", "Suspense", "Mistério", "Ficção científica")) { genre ->
                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                        Text(genre, color = Color.White, modifier = Modifier.padding(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun MovieRow(
    movies: List<Movie>,
    favorites: Set<Int>,
    onMovie: (Movie) -> Unit,
    onFavorite: (Movie) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(movies, key = { it.id }) { movie ->
            MovieCard(movie, movie.id in favorites, onMovie, onFavorite)
        }
    }
}

@Composable
private fun MovieCard(
    movie: Movie,
    isFavorite: Boolean,
    onMovie: (Movie) -> Unit,
    onFavorite: (Movie) -> Unit
) {
    Card(
        modifier = Modifier.width(160.dp).clickable { onMovie(movie) },
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column {
            Box(
                modifier = Modifier.fillMaxWidth().height(190.dp)
                    .background(Brush.verticalGradient(listOf(PurpleDark, Color(0xFF242029))))
            ) {
                Text(
                    movie.title.take(12),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center).padding(10.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                IconButton(
                    onClick = { onFavorite(movie) },
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isFavorite) "Remover dos favoritos" else "Adicionar aos favoritos",
                        tint = if (isFavorite) Purple else Color.White
                    )
                }
            }
            Column(Modifier.padding(10.dp)) {
                Text(movie.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${movie.year} • ${movie.rating}", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        title,
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 12.dp)
    )
}

@Composable
private fun SearchScreen(
    padding: PaddingValues,
    movies: List<Movie>,
    favorites: Set<Int>,
    onMovie: (Movie) -> Unit,
    onFavorite: (Movie) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = movies.filter { it.title.contains(query, true) || it.genre.contains(query, true) }

    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        Text("Pesquisar", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Filmes, séries ou gêneros") }
        )
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.id }) { movie ->
                SearchResult(movie, movie.id in favorites, onMovie, onFavorite)
            }
        }
    }
}

@Composable
private fun SearchResult(
    movie: Movie,
    isFavorite: Boolean,
    onMovie: (Movie) -> Unit,
    onFavorite: (Movie) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onMovie(movie) },
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(70.dp).clip(MaterialTheme.shapes.medium)
                    .background(Brush.verticalGradient(listOf(PurpleDark, Color(0xFF242029))))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(movie.title, color = Color.White, fontWeight = FontWeight.Bold)
                Text("${movie.genre} • ${movie.year}", color = Color.Gray)
                Text("★ ${movie.rating}", color = Purple)
            }
            IconButton(onClick = { onFavorite(movie) }) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Purple)
            }
        }
    }
}

@Composable
private fun FavoritesScreen(
    padding: PaddingValues,
    movies: List<Movie>,
    onMovie: (Movie) -> Unit,
    onFavorite: (Movie) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        Text("Favoritos", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        if (movies.isEmpty()) {
            Text("Você ainda não adicionou favoritos.", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(movies, key = { it.id }) { movie ->
                    SearchResult(movie, true, onMovie, onFavorite)
                }
            }
        }
    }
}

@Composable
private fun DetailsScreen(
    movie: Movie,
    isFavorite: Boolean,
    onBack: () -> Unit,
    onFavorite: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Background)) {
        Box(
            Modifier.fillMaxWidth().height(330.dp)
                .background(Brush.verticalGradient(listOf(PurpleDark, Background)))
        ) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart)) {
                Text("‹", color = Color.White, fontSize = 38.sp)
            }
            Text(
                movie.title,
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomStart).padding(20.dp)
            )
        }
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${movie.year} • ${movie.genre}", color = Color.Gray)
                Spacer(Modifier.weight(1f))
                Text("★ ${movie.rating}", color = Purple, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            Text(movie.description, color = Color.LightGray, lineHeight = 22.sp)
            Spacer(Modifier.height(20.dp))
            IconButton(onClick = onFavorite) {
                Icon(
                    if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    tint = Purple,
                    modifier = Modifier.size(30.dp)
                )
            }
        }
    }
}

@Composable
private fun ProfileScreen(padding: PaddingValues) {
    Column(
        Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text("Perfil", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text("CinePlay", color = Purple, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Configurações e preferências serão adicionadas nesta etapa.", color = Color.Gray)
    }
}
