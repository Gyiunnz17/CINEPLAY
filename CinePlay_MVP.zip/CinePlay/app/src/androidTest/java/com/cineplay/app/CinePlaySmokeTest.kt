package com.cineplay.app

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class CinePlaySmokeTest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    @Test
    fun homeShowsBrandAndNavigation() {
        rule.onNodeWithText("CINEPLAY").assertIsDisplayed()
        rule.onNodeWithText("Início").assertIsDisplayed()
        rule.onNodeWithText("Pesquisar").assertIsDisplayed()
        rule.onNodeWithText("Favoritos").assertIsDisplayed()
        rule.onNodeWithText("Perfil").assertIsDisplayed()
    }
}
