# CinePlay — MVP Android

Base inicial do aplicativo CinePlay, com interface escura roxo/preto.

## Incluído
- Início com destaque, séries e categorias
- Pesquisa local por título/gênero
- Detalhes do título
- Favoritos em memória durante a sessão
- Perfil inicial
- Navegação inferior
- Tema escuro
- Build release com R8/minificação
- Teste smoke básico

## Próximas etapas
1. Trocar catálogo de demonstração por uma fonte licenciada/legítima.
2. Persistir favoritos localmente.
3. Adicionar imagens reais com cache.
4. Adicionar estados de loading/erro/rede.
5. Testes de UI e navegação mais amplos.
6. Ícone, splash e identidade visual final.
7. Política de privacidade e dados para Play Console.
8. Gerar AAB assinado para publicação.

## Observação
O projeto mira Android 16 (API 36), requisito atual para novos envios ao Google Play.
